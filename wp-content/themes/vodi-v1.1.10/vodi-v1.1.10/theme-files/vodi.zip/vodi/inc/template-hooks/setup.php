<?php
/**
 * Theme setup hooks
 * 
 * @since 1.0.0
 */
/**
 * Setup
 */
add_action( 'after_setup_theme', 'vodi_register_image_sizes', 10 );