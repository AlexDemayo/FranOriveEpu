<?php
require_once get_template_directory() . '/inc/masvideos/template-tags/archives.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/archive-movies.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/archive-videos.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/archive-tv-shows.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/loop.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/single-tv-show.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/single-episode.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/single-video.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/single-movie.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/single-person.php';
require_once get_template_directory() . '/inc/masvideos/template-tags/my-account.php';