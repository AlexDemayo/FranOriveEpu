<?php
/**
 * Template hooks for widgets
 */

add_filter( 'widget_categories_args', 'vodi_modify_widget_categories_args', 10, 2 );