Vodi
==============================
Vodi is a WordPress Video Streaming Theme.

It features deep integration with MAS Videos plugin.


The codebase of Vodi is lean and extensible which will allow develoepers to easily add functionality to your site via child theme and/or custom plugin(s).

Vodi Documentation
==============================
You can view detailed Vodi documentation on the Vodi documentation web site.

Vodi help & support
==============================
MadrasThemes customers can get support at the Madras Themes support portal.